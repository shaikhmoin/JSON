//
//  ViewController.swift
//  JSON2
//
//  Created by MACOS on 6/12/17.
//  Copyright © 2017 MACOS. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITableViewDataSource,UITableViewDelegate {

    var final = [Any]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let str = String("https://query.yahooapis.com/v1/public/yql?q=select%20*%20from%20cricket.commentary%20where%20match_id%3D11985&format=json&diagnostics=true&env=store%3A%2F%2F0TxIGQMQbObzvU4Apia0V0&callback=")
    
        let url = URL(string: str!)
        
        do
        {
            let dt = try Data(contentsOf: url!)
            
            do
            {
                let dic = try JSONSerialization.jsonObject(with: dt, options: []) as! [String:Any]
                
                let dic1 = dic["query"] as! [String:Any]
                
                let dic2 = dic1["results"] as! [String:Any]
                
                let dic3 = dic2["Over"] as! [[String:Any]]
                
                for item in dic3
                {
                    let dic4 = item["Ball"] as! [[String:Any]]
                    
                    for item1 in dic4 {
                        final.append(item1)
                        //print(final)
                    }
                }
                
                
            }
            catch
            {
                
            }
        }
        catch
        {
            
        }
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return final.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell")
        
        let dicfinal = final[indexPath.row] as! [String:Any]
        
        cell?.textLabel?.text = dicfinal["c"] as! String
        
        return cell!
    }


}

