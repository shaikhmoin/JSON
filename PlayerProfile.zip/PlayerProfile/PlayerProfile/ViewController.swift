//
//  ViewController.swift
//  PlayerProfile
//
//  Created by MACOS on 6/13/17.
//  Copyright © 2017 MACOS. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITableViewDataSource,UITableViewDelegate {

    var final = [String:Any]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        var str = String("https://query.yahooapis.com/v1/public/yql?q=select%20*%20from%20cricket.player.profile%20where%20player_id%3D2962&format=json&diagnostics=true&env=store%3A%2F%2F0TxIGQMQbObzvU4Apia0V0&callback=")
        
        let url = URL(string: str!)
        
        do
        {
            let dt = try Data(contentsOf: url!)

            do
            {
                let dic = try JSONSerialization.jsonObject(with: dt, options: []) as! [String:Any]
                
                let dic1 = dic["query"] as! [String:Any]
                
                let dic2 = dic1["results"] as! [String:Any]
                
                let dic3 = dic2["PlayerProfile"] as! [String:Any]
                
                final = dic3["PersonalDetails"] as! [String:Any]
            }
            catch
            {
                
            }
            
        }
        catch
        {
            
        }
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 10
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell")
   
        cell?.textLabel?.text = final["FirstName"] as! String
        cell?.detailTextLabel?.text = final["LastName"] as! String
        
        let imgurl = final["PlayerLargeImgName"] as! String
        let data = NSData(contentsOf: NSURL(string: imgurl) as! URL)
        cell?.imageView?.image = UIImage(data: data as! Data)
        
        return cell!
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

