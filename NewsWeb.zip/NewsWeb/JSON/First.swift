//
//  First.swift
//  JSON
//
//  Created by MACOS on 6/12/17.
//  Copyright © 2017 MACOS. All rights reserved.
//

import UIKit

class First: UIViewController {

    var link = ""
    
    @IBOutlet var web: UIWebView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        let url = URL(string: link)
        web.loadRequest(URLRequest(url: url!))
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
}
