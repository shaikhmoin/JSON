//
//  Custom.swift
//  JSON3
//
//  Created by MACOS on 6/12/17.
//  Copyright © 2017 MACOS. All rights reserved.
//

import UIKit

class Custom: UITableViewCell {

    @IBOutlet var lblmtype: UILabel!
    @IBOutlet var lblsname: UILabel!
    @IBOutlet var lblsdate: UILabel!
    @IBOutlet var lbledate: UILabel!
    @IBOutlet var lblteam1: UILabel!
    @IBOutlet var lblteam2: UILabel!
    @IBOutlet var lblwon1: UILabel!
    @IBOutlet var lblwon2: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
